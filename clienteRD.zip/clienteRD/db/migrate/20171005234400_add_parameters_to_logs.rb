class AddParametersToLogs < ActiveRecord::Migration[5.0]
  def change
      add_column :logs, :usuario, :string, null: false
      add_column :logs, :descricao, :string, null: true
  end
end
