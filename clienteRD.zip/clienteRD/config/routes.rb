Rails.application.routes.draw do
  post "/fake" => "home#fake"
  post "/save" => "home#save"
  get "/home" => "home#home"
  get "/about" => "home#about"
  get "/contact" => "home#contact"
  get "/price" => "home#price"
  root "home#home"
end
