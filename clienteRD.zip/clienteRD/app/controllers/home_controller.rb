class HomeController < ApplicationController
    skip_before_filter :verify_authenticity_token

    def home
        render "home"
    end

    def about
    end
    
    def price
    end

    def contact
    end

    def fake
        render "home"
    end
end
