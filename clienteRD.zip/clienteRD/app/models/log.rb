class Log < ApplicationRecord
    def change
        create_table :logs do |t|
            
            t.string :usuario
            t.string :descricao
    
            t.timestamps
        end
    end
end
