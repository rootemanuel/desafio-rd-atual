Rails.application.routes.draw do
  post "/save" => "home#save"
  root "home#home"
end
