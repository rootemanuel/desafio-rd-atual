

class HomeController < ApplicationController
    skip_before_filter :verify_authenticity_token

    @@log ||= []

    def home
        @logs = @@log
    end

    def save
        @@log << Log.new(:usuario => params[:usuario], :descricao => params[:descricao], :created_at => DateTime.now.in_time_zone )        
    end
end
