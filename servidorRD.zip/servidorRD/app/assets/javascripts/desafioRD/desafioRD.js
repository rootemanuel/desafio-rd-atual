//Constantes
const RDANONY = "RDANONY";
const RDEMAIL = "RDEMAIL";

//Evento page load
window.onload = e => {
    let sys = system();
    sys.init();
}

window.onsubmit = e => {
    let email = e.target.email.value;

    if(email){
        localStorage.setItem(RDEMAIL,email);
    }
}

//Evento clicks
document.onclick = e => {
    let sys = system();

    var id = e.target.id;
    var type = e.target.type;
    var usuario = sys.srchAttributes()

    if(!id){
        id = "NO ID";
    }

    if(!type){
        type = "NO TYPE";
    }

    console.log(`USUARIO ${usuario} - CLICOU ${id}/${type}`);
    sys.save(usuario, `USUARIO ${usuario} - CLICOU ${id}/${type}`);
}

let system = function() {

    //Trata inicialização 
    let init = function() {
        if(!srchAttributes()){
            initCookie()
        }
    }

    //Inicializa LS
    let initCookie = function() {
        var uuid = guid();
        localStorage.setItem(RDANONY,uuid);
    }

    //Gera GUID
    let guid = function() {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000)
              .toString(16)
              .substring(1);
          }
          return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
            s4() + '-' + s4() + s4() + s4();
    }

    //Procura id caso exista
    let srchAttributes = function() {
        let anony = localStorage.getItem(RDANONY);
        let email = localStorage.getItem(RDEMAIL);
        
        if(email)
            return email;
    
        return anony;
    }

    //Metodo salvar request
    let saveRequest = function() {
        let usuario = sys.srchAttributes()
        let url = window.location
        
        save(usuario, `USUARIO ${usuario} - ACESSANDO ${url}`);
    }

    //Metodo salvar
    let save = function(usuario,descricao) {
        $.ajax({
            url: '/save',
            dataType: 'json',
            type: 'post',
            contentType: 'application/json',
            data: JSON.stringify( { "usuario": usuario, "descricao": descricao } ),
            processData: false,
            success: function( data, textStatus, jQxhr ){
                console.log("#R00T - DESAFIO RD - SALVOU")
            },
            error: function( jqXhr, textStatus, errorThrown ){
                console.log( errorThrown );
            }
        });
    }

    return {
        init: init,
        initCookie: initCookie,
        srchAttributes: srchAttributes,
        guid: guid,
        saveRequest: saveRequest,
        save: save
    }
}